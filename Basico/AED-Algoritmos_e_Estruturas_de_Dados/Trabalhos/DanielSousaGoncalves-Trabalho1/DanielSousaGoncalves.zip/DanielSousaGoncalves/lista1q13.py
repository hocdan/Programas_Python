#13a) Qual o resultado de cada um dos comandos seguintes:

#A) ‘Python’[1]

print('a)',('Python'[1]))

#B) ‘Strings são sequências de caracteres.’[5]

print('b)', 'Strings são sequências de caracteres.'[5])

#C) len(‘maravilhoso’)

print('c)', len('maravilhoso'))

#D) ‘Misterio’[:4]

print('d)', 'Misterio'[:4])

#E) ‘p’ in ‘Pineapple

print('e)', 'p' in 'Pineapple')

#F) ‘apple’in‘Pineapple

print('f)', 'apple' in 'Pineapple')

#G) ‘pear’ not in ‘Pineapple

print('g)', 'pear' not in 'Pineapple')

#H) ‘apple’ > ‘pineapple’

print('h)', 'apple' > 'pineapple')

#I) ‘pineapple’ < ‘Peach’

print('i)', 'pineapple' < 'Peach')